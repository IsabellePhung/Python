# Introduction
lab = 0
while lab == 0:
    introduction = int(input("Welcome to Alberta Hospital (AH) Management system\n"
                      "Select from the following options, or selct 0 to stop:\n"
                      "1 - Doctors\n"
                      "2 - Facilities\n"
                      "3 - Laboratories\n"
                      "4 - Patients\n"))
    if introduction == 0:
        break

    # Lab menu stuff
    while introduction == 3:
        print("Laboratories Menu: \n"
              "1 - Display laboratories list\n"
              "2 - Add Laboratory\n"
              "3 - Back to the main menu\n")
        lab_menu = int(input())
        if lab_menu == 1:
            with open("laboratories.txt") as f:
                print(f.read())
        if lab_menu == 2:
            lab_facility = input("Enter Laboratory Facility:")
            lab_cost = input("Enter Laboratory Cost:")
            with open("laboratories.txt", "a") as f:
                f.write("\n")
            with open("laboratories.txt" , "a" ) as f:
                f.write("lab_facility\n")
            with open("laboratories.txt", "a") as f:
                f.write("")
            with open("laboratories.txt", "a") as f:
                f.write("lab_cost\n")
        if lab_menu == 3:
            break
